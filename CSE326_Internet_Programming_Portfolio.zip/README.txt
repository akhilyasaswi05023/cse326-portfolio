# CSE326 Student Portfolio Website

## Preview locally
1. Extract this ZIP.
2. Open `index.html` in a browser.

## Publish free with GitHub Pages
1. Sign in at https://github.com/ or create an account.
2. Click **New repository**.
3. Give the repository a name such as `cse326-portfolio` and set it to **Public**.
4. Create the repository.
5. Choose **Add file → Upload files** and upload `index.html`.
6. Click **Commit changes**.
7. Open **Settings → Pages**.
8. Under **Build and deployment**, select **Deploy from a branch**.
9. Choose branch `main` and folder `/ (root)`, then click **Save**.
10. Wait a few minutes and refresh the Pages section. Open the published link shown there. It will usually look like:
   https://YOUR-GITHUB-USERNAME.github.io/cse326-portfolio/

## Certificate privacy
The certificate PDF is not included in this starter website. The site shows the certificate date and code you provided. If you decide to publish the PDF, add it as `certificate.pdf` and uncomment the certificate link in `index.html`. Anyone who can access your public site may be able to view a published certificate.

## Before submitting to EDU-Revolution
- Confirm the current CSE326 project eligibility and required proof with the portal/faculty.
- A course-completion certificate is not automatically proof that a separate project qualifies.
- Edit the project description so it accurately reflects what you personally built and understand.
- Upload the Simplilearn certificate and other documents requested by the portal.
